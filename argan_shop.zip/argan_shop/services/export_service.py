import io
from datetime import datetime
from models import Commande, LigneCommande, Produit, db
from sqlalchemy import func


def get_statistics():
    """Get dashboard statistics."""
    total_commandes = Commande.query.count()
    chiffre_affaires = db.session.query(func.sum(Commande.montant_total)).scalar() or 0
    total_produits = Produit.query.count()

    # Recent orders
    commandes_recentes = Commande.query.order_by(Commande.date_commande.desc()).limit(5).all()

    # Best selling products
    best_sellers = db.session.query(
        LigneCommande.nom_produit,
        func.sum(LigneCommande.quantite).label('total_qty')
    ).group_by(LigneCommande.nom_produit).order_by(
        func.sum(LigneCommande.quantite).desc()
    ).limit(5).all()

    # Orders by status
    by_status = {}
    for s in ['CONFIRMEE', 'EN_PREPARATION', 'EXPEDIEE', 'LIVREE']:
        by_status[s] = Commande.query.filter_by(statut=s).count()

    return {
        'total_commandes': total_commandes,
        'chiffre_affaires': round(chiffre_affaires, 2),
        'total_produits': total_produits,
        'commandes_recentes': commandes_recentes,
        'best_sellers': best_sellers,
        'by_status': by_status
    }


def export_excel():
    """Export sales report as Excel."""
    from openpyxl import Workbook
    from openpyxl.styles import Font, Alignment, PatternFill

    wb = Workbook()
    ws = wb.active
    ws.title = "Rapport des ventes"

    # Header style
    header_font = Font(bold=True, color="FFFFFF", size=12)
    header_fill = PatternFill(start_color="5C3D2E", end_color="5C3D2E", fill_type="solid")

    # Title
    ws.merge_cells('A1:F1')
    ws['A1'] = 'Rapport des Ventes - Coopérative AIT TAMNAT'
    ws['A1'].font = Font(bold=True, size=16)
    ws['A2'] = f"Généré le {datetime.now().strftime('%d/%m/%Y %H:%M')}"

    # Headers
    headers = ['Numéro', 'Date', 'Client', 'Email', 'Montant (MAD)', 'Statut']
    for col, h in enumerate(headers, 1):
        cell = ws.cell(row=4, column=col, value=h)
        cell.font = header_font
        cell.fill = header_fill
        cell.alignment = Alignment(horizontal='center')

    # Data
    commandes = Commande.query.order_by(Commande.date_commande.desc()).all()
    for i, cmd in enumerate(commandes, 5):
        ws.cell(row=i, column=1, value=cmd.numero)
        ws.cell(row=i, column=2, value=cmd.date_commande.strftime('%d/%m/%Y'))
        ws.cell(row=i, column=3, value=cmd.nom_client)
        ws.cell(row=i, column=4, value=cmd.email_client)
        ws.cell(row=i, column=5, value=cmd.montant_total)
        ws.cell(row=i, column=6, value=cmd.statut)

    # Column widths
    for col_letter in ['A', 'B', 'C', 'D', 'E', 'F']:
        ws.column_dimensions[col_letter].width = 20

    output = io.BytesIO()
    wb.save(output)
    output.seek(0)
    return output


def export_pdf():
    """Export sales report as PDF."""
    from reportlab.lib.pagesizes import A4
    from reportlab.lib import colors
    from reportlab.platypus import SimpleDocTemplate, Table, TableStyle, Paragraph, Spacer
    from reportlab.lib.styles import getSampleStyleSheet

    output = io.BytesIO()
    doc = SimpleDocTemplate(output, pagesize=A4)
    styles = getSampleStyleSheet()
    elements = []

    # Title
    elements.append(Paragraph("Rapport des Ventes - Coopérative AIT TAMNAT", styles['Title']))
    elements.append(Paragraph(f"Généré le {datetime.now().strftime('%d/%m/%Y %H:%M')}", styles['Normal']))
    elements.append(Spacer(1, 20))

    # Statistics
    stats = get_statistics()
    elements.append(Paragraph(f"Total commandes: {stats['total_commandes']}", styles['Normal']))
    elements.append(Paragraph(f"Chiffre d'affaires: {stats['chiffre_affaires']} MAD", styles['Normal']))
    elements.append(Spacer(1, 20))

    # Table
    data = [['Numéro', 'Date', 'Client', 'Montant', 'Statut']]
    commandes = Commande.query.order_by(Commande.date_commande.desc()).all()
    for cmd in commandes:
        data.append([
            cmd.numero,
            cmd.date_commande.strftime('%d/%m/%Y'),
            cmd.nom_client,
            f"{cmd.montant_total} MAD",
            cmd.statut
        ])

    if len(data) > 1:
        table = Table(data)
        table.setStyle(TableStyle([
            ('BACKGROUND', (0, 0), (-1, 0), colors.HexColor('#5C3D2E')),
            ('TEXTCOLOR', (0, 0), (-1, 0), colors.white),
            ('ALIGN', (0, 0), (-1, -1), 'CENTER'),
            ('FONTSIZE', (0, 0), (-1, 0), 10),
            ('BOTTOMPADDING', (0, 0), (-1, 0), 12),
            ('GRID', (0, 0), (-1, -1), 1, colors.black),
        ]))
        elements.append(table)

    doc.build(elements)
    output.seek(0)
    return output
