from flask_mail import Mail, Message
from flask import current_app
import logging

mail = Mail()
logger = logging.getLogger(__name__)


def envoyer_email_confirmation_commande(commande):
    """Send order confirmation email to client and admin."""
    try:
        # Email to client
        msg_client = Message(
            subject=f"Confirmation de commande {commande.numero} - Coopérative AIT TAMNAT",
            recipients=[commande.email_client]
        )
        lignes_html = ""
        for l in commande.lignes:
            lignes_html += f"<tr><td>{l.nom_produit}</td><td>{l.quantite}</td><td>{l.prix_unitaire} MAD</td><td>{l.sous_total()} MAD</td></tr>"

        msg_client.html = f"""
        <h2>Merci pour votre commande!</h2>
        <p><strong>Numéro de commande:</strong> {commande.numero}</p>
        <p><strong>Date:</strong> {commande.date_commande.strftime('%d/%m/%Y %H:%M')}</p>
        <table border="1" cellpadding="5">
            <tr><th>Produit</th><th>Quantité</th><th>Prix unitaire</th><th>Sous-total</th></tr>
            {lignes_html}
        </table>
        <p><strong>Total: {commande.montant_total} MAD</strong></p>
        <p>Suivez votre commande sur notre site avec le numéro: {commande.numero}</p>
        <p>Coopérative AIT TAMNAT</p>
        """
        mail.send(msg_client)

        # Email to admin
        msg_admin = Message(
            subject=f"Nouvelle commande {commande.numero}",
            recipients=[current_app.config['ORDER_RECIPIENT_EMAIL']]
        )
        msg_admin.html = f"""
        <h2>Nouvelle commande reçue</h2>
        <p><strong>Numéro:</strong> {commande.numero}</p>
        <p><strong>Client:</strong> {commande.nom_client}</p>
        <p><strong>Email:</strong> {commande.email_client}</p>
        <p><strong>Téléphone:</strong> {commande.telephone_client}</p>
        <p><strong>Adresse:</strong> {commande.adresse_client}</p>
        <table border="1" cellpadding="5">
            <tr><th>Produit</th><th>Quantité</th><th>Prix unitaire</th><th>Sous-total</th></tr>
            {lignes_html}
        </table>
        <p><strong>Total: {commande.montant_total} MAD</strong></p>
        """
        mail.send(msg_admin)
        return True
    except Exception as e:
        logger.error(f"Erreur envoi email: {e}")
        return False


def notifier_service_livraison(commande):
    """Notify delivery service about status change."""
    logger.info(f"[SERVICE LIVRAISON] Commande {commande.numero} - Statut: {commande.statut}")
    try:
        msg = Message(
            subject=f"Mise à jour commande {commande.numero} - {commande.statut}",
            recipients=[current_app.config['ORDER_RECIPIENT_EMAIL']]
        )
        msg.html = f"""
        <h2>Mise à jour de commande</h2>
        <p><strong>Numéro:</strong> {commande.numero}</p>
        <p><strong>Nouveau statut:</strong> {commande.statut}</p>
        <p><strong>Client:</strong> {commande.nom_client}</p>
        <p><strong>Adresse:</strong> {commande.adresse_client}</p>
        """
        mail.send(msg)
    except Exception as e:
        logger.error(f"Erreur notification livraison: {e}")
