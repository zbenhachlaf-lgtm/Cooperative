from flask import Blueprint, render_template, request, redirect, url_for, flash, send_file
from flask_login import login_user, logout_user, login_required, current_user
from models import db, Utilisateur, Produit, Categorie, Commande, LigneCommande
from services.export_service import get_statistics, export_excel, export_pdf
from services.email_service import notifier_service_livraison
from werkzeug.utils import secure_filename
import os

admin_bp = Blueprint('admin', __name__, url_prefix='/admin')


@admin_bp.route('/login', methods=['GET', 'POST'])
def login():
    if current_user.is_authenticated:
        return redirect(url_for('admin.dashboard'))

    if request.method == 'POST':
        email = request.form.get('email', '')
        password = request.form.get('password', '')
        user = Utilisateur.query.filter_by(email=email).first()
        if user and user.check_password(password) and user.is_admin():
            login_user(user)
            return redirect(url_for('admin.dashboard'))
        flash('Email ou mot de passe incorrect.', 'danger')

    return render_template('admin/login.html')


@admin_bp.route('/logout')
@login_required
def logout():
    logout_user()
    return redirect(url_for('admin.login'))


@admin_bp.route('/dashboard')
@login_required
def dashboard():
    stats = get_statistics()
    return render_template('admin/dashboard.html', stats=stats)


# ---- PRODUCTS CRUD ----
@admin_bp.route('/produits')
@login_required
def produits_liste():
    search = request.args.get('search', '')
    query = Produit.query
    if search:
        query = query.filter(Produit.nom.ilike(f'%{search}%'))
    produits = query.order_by(Produit.date_ajout.desc()).all()
    return render_template('admin/produits_liste.html', produits=produits, search=search)


@admin_bp.route('/produits/ajouter', methods=['GET', 'POST'])
@login_required
def produit_ajouter():
    categories = Categorie.query.all()
    if request.method == 'POST':
        image_file = 'default.jpg'
        if 'image' in request.files:
            file = request.files['image']
            if file.filename:
                filename = secure_filename(file.filename)
                upload_path = os.path.join('static', 'images', 'products', filename)
                file.save(upload_path)
                image_file = filename

        produit = Produit(
            nom=request.form['nom'],
            description=request.form.get('description', ''),
            categorie=request.form.get('categorie', ''),
            marque=request.form.get('marque', ''),
            prix=float(request.form.get('prix', 0)),
            image=image_file,
            usage=request.form.get('usage', ''),
            disponible='disponible' in request.form
        )

        cat = Categorie.query.filter_by(libelle=produit.categorie).first()
        if cat:
            produit.categorie_id = cat.id

        db.session.add(produit)
        db.session.commit()
        flash('Produit ajouté avec succès.', 'success')
        return redirect(url_for('admin.produits_liste'))

    return render_template('admin/produit_form.html', produit=None, categories=categories)


@admin_bp.route('/produits/modifier/<int:id>', methods=['GET', 'POST'])
@login_required
def produit_modifier(id):
    produit = Produit.query.get_or_404(id)
    categories = Categorie.query.all()

    if request.method == 'POST':
        produit.nom = request.form['nom']
        produit.description = request.form.get('description', '')
        produit.categorie = request.form.get('categorie', '')
        produit.marque = request.form.get('marque', '')
        produit.prix = float(request.form.get('prix', 0))
        produit.usage = request.form.get('usage', '')
        produit.disponible = 'disponible' in request.form

        if 'image' in request.files:
            file = request.files['image']
            if file.filename:
                filename = secure_filename(file.filename)
                upload_path = os.path.join('static', 'images', 'products', filename)
                file.save(upload_path)
                produit.image = filename

        cat = Categorie.query.filter_by(libelle=produit.categorie).first()
        if cat:
            produit.categorie_id = cat.id

        db.session.commit()
        flash('Produit modifié avec succès.', 'success')
        return redirect(url_for('admin.produits_liste'))

    return render_template('admin/produit_form.html', produit=produit, categories=categories)


@admin_bp.route('/produits/supprimer/<int:id>')
@login_required
def produit_supprimer(id):
    produit = Produit.query.get_or_404(id)
    db.session.delete(produit)
    db.session.commit()
    flash('Produit supprimé.', 'success')
    return redirect(url_for('admin.produits_liste'))


# ---- ORDERS ----
@admin_bp.route('/commandes')
@login_required
def commandes_liste():
    statut_filter = request.args.get('statut', '')
    query = Commande.query
    if statut_filter:
        query = query.filter_by(statut=statut_filter)
    commandes = query.order_by(Commande.date_commande.desc()).all()
    return render_template('admin/commandes_liste.html', commandes=commandes, statut_filter=statut_filter)


@admin_bp.route('/commandes/<numero>')
@login_required
def commande_detail(numero):
    commande = Commande.query.filter_by(numero=numero).first_or_404()
    return render_template('admin/commande_detail.html', commande=commande)


@admin_bp.route('/commandes/<numero>/statut', methods=['POST'])
@login_required
def commande_update_statut(numero):
    commande = Commande.query.filter_by(numero=numero).first_or_404()
    new_statut = request.form.get('statut', '')
    valid = ['CONFIRMEE', 'EN_PREPARATION', 'EXPEDIEE', 'LIVREE']
    if new_statut in valid:
        commande.statut = new_statut
        db.session.commit()
        notifier_service_livraison(commande)
        flash(f'Statut mis à jour: {new_statut}', 'success')
    return redirect(url_for('admin.commande_detail', numero=numero))


@admin_bp.route('/commandes/historique')
@login_required
def historique():
    commandes = Commande.query.order_by(Commande.numero).all()
    return render_template('admin/historique.html', commandes=commandes)


# ---- EXPORT ----
@admin_bp.route('/export')
@login_required
def export_rapport():
    fmt = request.args.get('format', 'excel')
    if fmt == 'pdf':
        output = export_pdf()
        return send_file(output, mimetype='application/pdf',
                         as_attachment=True, download_name='rapport_ventes.pdf')
    else:
        output = export_excel()
        return send_file(output,
                         mimetype='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
                         as_attachment=True, download_name='rapport_ventes.xlsx')
