from flask import Blueprint, render_template, request, session, redirect, url_for, flash, jsonify
from models import db, Produit, Categorie, Avis, Commande, LigneCommande, Article
from services.email_service import envoyer_email_confirmation_commande

client_bp = Blueprint('client', __name__)


@client_bp.route('/')
def accueil():
    produits = Produit.query.filter_by(disponible=True).limit(8).all()
    categories = Categorie.query.all()
    return render_template('client/accueil.html', produits=produits, categories=categories)


@client_bp.route('/catalogue')
def catalogue():
    page = request.args.get('page', 1, type=int)
    search = request.args.get('search', '')
    categorie = request.args.get('categorie', '')
    prix_min = request.args.get('prix_min', type=float)
    prix_max = request.args.get('prix_max', type=float)

    query = Produit.query.filter_by(disponible=True)

    if search:
        query = query.filter(Produit.nom.ilike(f'%{search}%'))
    if categorie:
        query = query.filter_by(categorie=categorie)
    if prix_min is not None:
        query = query.filter(Produit.prix >= prix_min)
    if prix_max is not None:
        query = query.filter(Produit.prix <= prix_max)

    produits = query.order_by(Produit.date_ajout.desc()).paginate(page=page, per_page=12, error_out=False)
    categories = Categorie.query.all()

    return render_template('client/catalogue.html',
                           produits=produits,
                           categories=categories,
                           search=search,
                           categorie_selected=categorie,
                           prix_min=prix_min,
                           prix_max=prix_max)


@client_bp.route('/produit/<int:id>')
def produit_detail(id):
    produit = Produit.query.get_or_404(id)
    avis = Avis.query.filter_by(produit_id=id).order_by(Avis.date_publication.desc()).all()
    return render_template('client/produit_detail.html', produit=produit, avis=avis)


@client_bp.route('/produit/<int:id>/avis', methods=['POST'])
def ajouter_avis(id):
    produit = Produit.query.get_or_404(id)
    avis = Avis(
        note=int(request.form.get('note', 5)),
        commentaire=request.form.get('commentaire', ''),
        nom_client=request.form.get('nom_client', 'Anonyme'),
        produit_id=id
    )
    db.session.add(avis)
    db.session.commit()
    flash('Votre avis a été publié !', 'success')
    return redirect(url_for('client.produit_detail', id=id))


# ---- CART (SESSION) ----
def get_cart():
    if 'cart' not in session:
        session['cart'] = {}
    return session['cart']


@client_bp.route('/panier')
def panier():
    cart = get_cart()
    items = []
    total = 0
    for pid, qty in cart.items():
        produit = Produit.query.get(int(pid))
        if produit:
            sous_total = produit.prix * qty
            items.append({'produit': produit, 'quantite': qty, 'sous_total': sous_total})
            total += sous_total
    return render_template('client/panier.html', items=items, total=total)


@client_bp.route('/panier/ajouter/<int:id>', methods=['POST'])
def ajouter_au_panier(id):
    cart = get_cart()
    qty = int(request.form.get('quantite', 1))
    pid = str(id)
    cart[pid] = cart.get(pid, 0) + qty
    session['cart'] = cart
    session.modified = True
    flash('Produit ajouté au panier !', 'success')

    if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
        return jsonify({'success': True, 'cart_count': sum(cart.values())})
    return redirect(request.referrer or url_for('client.catalogue'))


@client_bp.route('/panier/modifier/<int:id>', methods=['POST'])
def modifier_panier(id):
    cart = get_cart()
    pid = str(id)
    qty = int(request.form.get('quantite', 1))
    if qty > 0:
        cart[pid] = qty
    else:
        cart.pop(pid, None)
    session['cart'] = cart
    session.modified = True
    return redirect(url_for('client.panier'))


@client_bp.route('/panier/supprimer/<int:id>')
def supprimer_du_panier(id):
    cart = get_cart()
    cart.pop(str(id), None)
    session['cart'] = cart
    session.modified = True
    return redirect(url_for('client.panier'))


@client_bp.route('/panier/vider')
def vider_panier():
    session['cart'] = {}
    session.modified = True
    return redirect(url_for('client.panier'))


# ---- ORDER ----
@client_bp.route('/commander', methods=['GET', 'POST'])
def commander():
    cart = get_cart()
    if not cart:
        flash('Votre panier est vide.', 'warning')
        return redirect(url_for('client.catalogue'))

    if request.method == 'POST':
        # Create order
        numero = Commande.generer_numero()
        commande = Commande(
            numero=numero,
            nom_client=request.form['nom'],
            email_client=request.form['email'],
            telephone_client=request.form.get('telephone', ''),
            adresse_client=request.form.get('adresse', ''),
            statut='CONFIRMEE'
        )
        db.session.add(commande)
        db.session.flush()

        total = 0
        for pid, qty in cart.items():
            produit = Produit.query.get(int(pid))
            if produit:
                ligne = LigneCommande(
                    commande_id=commande.id,
                    produit_id=produit.id,
                    nom_produit=produit.nom,
                    quantite=qty,
                    prix_unitaire=produit.prix
                )
                db.session.add(ligne)
                total += produit.prix * qty

        commande.montant_total = total
        db.session.commit()

        # Send emails
        envoyer_email_confirmation_commande(commande)

        # Clear cart
        session['cart'] = {}
        session.modified = True

        return redirect(url_for('client.confirmation', numero=numero))

    # GET - show order form
    items = []
    total = 0
    for pid, qty in cart.items():
        produit = Produit.query.get(int(pid))
        if produit:
            sous_total = produit.prix * qty
            items.append({'produit': produit, 'quantite': qty, 'sous_total': sous_total})
            total += sous_total

    return render_template('client/commander.html', items=items, total=total)


@client_bp.route('/confirmation/<numero>')
def confirmation(numero):
    commande = Commande.query.filter_by(numero=numero).first_or_404()
    return render_template('client/confirmation.html', commande=commande)


@client_bp.route('/suivi', methods=['GET', 'POST'])
def suivi():
    commande = None
    error = None
    if request.method == 'POST' or request.args.get('numero'):
        numero = request.form.get('numero', '') or request.args.get('numero', '')
        numero = numero.strip().upper()
        if not numero.startswith('#'):
            numero = '#' + numero
        commande = Commande.query.filter_by(numero=numero).first()
        if not commande:
            error = True
    return render_template('client/suivi.html', commande=commande, error=error)


# ---- BLOG ----
@client_bp.route('/blog')
def blog():
    articles = Article.query.order_by(Article.date_publication.desc()).all()
    return render_template('client/blog.html', articles=articles)


@client_bp.route('/blog/<int:id>')
def article_detail(id):
    article = Article.query.get_or_404(id)
    return render_template('client/article.html', article=article)


# ---- REVIEWS ----
@client_bp.route('/avis')
def avis():
    all_avis = Avis.query.order_by(Avis.date_publication.desc()).all()
    return render_template('client/avis.html', all_avis=all_avis)


# ---- CONTACT ----
@client_bp.route('/contact')
def contact():
    return render_template('client/contact.html')


# ---- LANGUAGE ----
@client_bp.route('/set-lang/<lang>')
def set_lang(lang):
    if lang in ['fr', 'en', 'ar']:
        session['lang'] = lang
        session.modified = True
    return redirect(request.referrer or url_for('client.accueil'))


# ---- API ENDPOINTS (AJAX) ----
@client_bp.route('/api/cart-count')
def cart_count():
    cart = get_cart()
    return jsonify({'count': sum(cart.values())})


@client_bp.route('/api/search')
def api_search():
    q = request.args.get('q', '')
    produits = Produit.query.filter(
        Produit.disponible == True,
        Produit.nom.ilike(f'%{q}%')
    ).limit(10).all()
    return jsonify([{
        'id': p.id, 'nom': p.nom, 'prix': p.prix,
        'image': p.image, 'categorie': p.categorie
    } for p in produits])
