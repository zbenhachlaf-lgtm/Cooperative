// ===== Mobile Nav Toggle =====
document.addEventListener('DOMContentLoaded', function() {
    const toggle = document.querySelector('.nav-toggle');
    const links = document.querySelector('.nav-links');
    if (toggle && links) {
        toggle.addEventListener('click', () => links.classList.toggle('show'));
    }

    // Auto-hide flash messages
    setTimeout(() => {
        document.querySelectorAll('.flash-msg').forEach(el => {
            el.style.opacity = '0';
            el.style.transform = 'translateX(100px)';
            setTimeout(() => el.remove(), 300);
        });
    }, 4000);

    // Star rating selector
    const starInputs = document.querySelectorAll('.star-input');
    starInputs.forEach(star => {
        star.addEventListener('click', function() {
            const val = this.dataset.value;
            document.getElementById('note-input').value = val;
            document.querySelectorAll('.star-input').forEach(s => {
                s.classList.toggle('active', s.dataset.value <= val);
            });
        });
    });
});

// ===== AJAX Add to Cart =====
function addToCart(productId) {
    const qty = document.getElementById('qty-' + productId);
    const formData = new FormData();
    formData.append('quantite', qty ? qty.value : 1);

    fetch('/panier/ajouter/' + productId, {
        method: 'POST',
        body: formData,
        headers: { 'X-Requested-With': 'XMLHttpRequest' }
    })
    .then(res => res.json())
    .then(data => {
        if (data.success) {
            const badge = document.querySelector('.cart-badge');
            if (badge) badge.textContent = data.cart_count;
            showFlash('Produit ajouté au panier !', 'success');
        }
    })
    .catch(() => {
        // Fallback: submit form normally
        const form = document.getElementById('cart-form-' + productId);
        if (form) form.submit();
    });
}

function showFlash(msg, type) {
    const container = document.querySelector('.flash-messages') || createFlashContainer();
    const div = document.createElement('div');
    div.className = 'flash-msg ' + type;
    div.textContent = msg;
    container.appendChild(div);
    setTimeout(() => {
        div.style.opacity = '0';
        setTimeout(() => div.remove(), 300);
    }, 3000);
}

function createFlashContainer() {
    const c = document.createElement('div');
    c.className = 'flash-messages';
    document.body.appendChild(c);
    return c;
}

// ===== Live Search =====
let searchTimeout;
function liveSearch(input) {
    clearTimeout(searchTimeout);
    searchTimeout = setTimeout(() => {
        const q = input.value.trim();
        if (q.length < 2) return;
        fetch('/api/search?q=' + encodeURIComponent(q))
        .then(res => res.json())
        .then(data => {
            const results = document.getElementById('search-results');
            if (!results) return;
            results.innerHTML = '';
            data.forEach(p => {
                const a = document.createElement('a');
                a.href = '/produit/' + p.id;
                a.className = 'search-result-item';
                a.innerHTML = `<strong>${p.nom}</strong> — ${p.prix} MAD`;
                results.appendChild(a);
            });
            results.style.display = data.length ? 'block' : 'none';
        });
    }, 300);
}
